<?php
class N1_Facebook {

    function __construct(){
        
    }
}