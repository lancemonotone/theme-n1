<?php if ( is_active_sidebar( 'sidebar-archive-0' )){?>
<div id="archive-widgets">
	<?php dynamic_sidebar( 'sidebar-archive-0' );?>
</div>
<?php }?>