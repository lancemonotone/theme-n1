<div class="main-content">
	<?php dynamic_sidebar( 'sidebar-toc-1' );?>
</div><!-- .main-content -->
<div class="sharing">
	<?php dynamic_sidebar( 'sidebar-toc-0' );?>
</div><!-- .sharing -->
<section id="supplementary" class="supp">
	<?php dynamic_sidebar( 'sidebar-toc-2' );?>
</div><!-- #supplementary -->