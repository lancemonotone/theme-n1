<div class="strux-tab-320fill strux-desk-320fill strux-wide-50">
	<?php dynamic_sidebar( 'sidebar-home-0' ); ?>
</div><!-- .strux-wide-50 -->

<div class="strux-tab-320fill strux-desk-320fill strux-wide-25">
	<?php dynamic_sidebar( 'sidebar-home-1' ); ?>
</div><!-- .strux-wide-25 -->

<div class="featured strux-tab-320min strux-desk-320min strux-wide-25">
	<?php dynamic_sidebar( 'sidebar-home-2' ); ?>
</div><!-- .strux-wide-25 -->