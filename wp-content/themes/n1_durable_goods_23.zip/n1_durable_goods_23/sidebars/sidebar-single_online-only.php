<?php if ( is_active_sidebar( 'sidebar-online-only-0' )){?>
<section class="current-posts" id="current-posts">
	<?php dynamic_sidebar( 'sidebar-online-only-0' );?>
</section><!-- #current-posts -->
<?php }?>