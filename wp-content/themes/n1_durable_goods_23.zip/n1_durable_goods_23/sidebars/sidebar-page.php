<?php if ( is_active_sidebar( 'sidebar-page-0' )){?>
<div class="first page-widgets">
	<?php dynamic_sidebar( 'sidebar-page-0' );?>
</div>
<?php }?>