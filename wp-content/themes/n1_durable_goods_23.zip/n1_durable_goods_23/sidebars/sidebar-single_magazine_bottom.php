<section id="supplementary" class="supp">
	<?php dynamic_sidebar( 'sidebar-article-1' );?>
</section><!-- /#supplementary -->