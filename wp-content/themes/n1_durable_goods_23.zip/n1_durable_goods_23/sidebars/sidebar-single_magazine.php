<section id="issue-meta" class="issue meta wrapper">
	<section class="issue meta postinfo">
		<?php dynamic_sidebar( 'sidebar-article-0' );?>
	</section><!-- .issue.meta.postinfo -->
</section><!-- #issue-meta -->