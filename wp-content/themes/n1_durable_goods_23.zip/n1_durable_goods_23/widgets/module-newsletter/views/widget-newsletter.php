<section class="newsletter">
<div class="floatwrapper">
	<h3 class="newsletter category"><span class="module-hed">Email Newsletter</span></h3>
	<p class="newsletter dek"><?php _e('Get n+1 in your inbox.')?></p>
		<form action="https://nplusonemag.us1.list-manage.com/subscribe/post" class="newsletter signup">	
			<fieldset>
				<label for="email" class="newsletter email"><?php _e('Email Address')?></label>
				<input type="text" placeholder="email address" class="form-text newsletter email text" name="MERGE0">
			</fieldset>					
			<fieldset class="newsletter actions">
				<input type="submit" value="Sign Up" class="newsletter submit">
			</fieldset>
			<input type="hidden" name="u" value="65397ab5874a671de57cc5c34">
			<input type="hidden" name="id" value="b822eb7b82">
		</form>
</div>
</section>
